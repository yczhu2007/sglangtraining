# 第二次挑战：SGLang 前缀缓存与请求流程

本目录包含两组 `/generate` 实验的输入、逐请求结果、汇总表和报告。所有命令在 **Ubuntu WSL 的 bash** 中执行；示例路径对应本次实验所在的 `E:\sglangtraining`。

## 环境与安装

本机验证环境：Ubuntu 22.04.5 LTS（WSL）、Python 3.10.12、NVIDIA GeForce RTX 5060 Laptop GPU（8 GB，驱动 592.01）、SGLang 0.5.14、Ray 2.56.0、Qwen/Qwen3-0.6B。服务环境另有 Transformers 5.8.1、PyTorch 2.11.0；回放环境的 Requests 为 2.34.2。需要可用的 NVIDIA 驱动和 WSL GPU 支持。

已有这两个环境时可跳过安装。新环境可按以下方式安装相同的 Python 包；首次下载模型需要访问 Hugging Face：

```bash
python3 -m venv ~/sglang-env
~/sglang-env/bin/python -m pip install --upgrade pip
~/sglang-env/bin/python -m pip install 'sglang==0.5.14' 'transformers==5.8.1'
~/sglang-env/bin/hf download Qwen/Qwen3-0.6B

python3 -m venv ~/ray-env
~/ray-env/bin/python -m pip install --upgrade pip
~/ray-env/bin/python -m pip install 'ray==2.56.0' 'requests==2.34.2'
```

## 启动与核对

在**终端 A** 启动服务，等待服务显示已就绪。默认启用 Radix Cache，不添加 `--disable-radix-cache`：

```bash
~/sglang-env/bin/python -m sglang.launch_server \
  --model-path Qwen/Qwen3-0.6B --host 127.0.0.1 --port 30000
```

在**终端 B** 执行。输入检查和预检不会发送测量请求；`run.py` 是一次流式接口试运行：

```bash
cd /mnt/e/sglangtraining/HW2-朱喻辰
~/sglang-env/bin/python src/target1/test_prepare_inputs.py
~/sglang-env/bin/python src/target1/save_inputs.py
~/ray-env/bin/python src/target1/replay.py --check
~/sglang-env/bin/python src/target1/run.py
~/ray-env/bin/python src/target1/measure.py
```

`save_inputs.py` 会重建两组请求清单和共享组预热输入。当前提交的逐请求结果已存在，`replay.py` 会拒绝覆盖它们。若确需**重新测量**，先在目录外备份两组 `request_results.jsonl` 与 `summary.csv`，再移走两组旧 `request_results.jsonl`；确认服务空闲后依次运行：

```bash
~/ray-env/bin/python src/target1/replay.py shared_prefix
~/ray-env/bin/python src/target1/replay.py dispersed_prefix
~/ray-env/bin/python src/target1/summarize.py
```

每组回放会先发短请求预热服务，再调用 `/flush_cache`；共享组随后额外发送一条 2048 token 共享前缀预热请求，均不计入 32 条测量结果。两组各 32 条，每条输入 2112 token、输出 16 token，Ray 每批最多同时发送 8 条。采样参数为 `temperature=0`、`max_new_tokens=16`、`ignore_eos=true`、`sampling_seed=2026`。

仅需核对**已提交的结果**时，不用启动服务，也不用重新回放：

```bash
cd /mnt/e/sglangtraining/HW2-朱喻辰
~/ray-env/bin/python src/target1/replay.py --check
~/ray-env/bin/python src/target1/summarize.py
```

## 文件与指标

| 文件 | 用途 |
| --- | --- |
| `src/target1/run.py` | 构造可比输入并试发一次流式 `/generate` 请求 |
| `src/target1/test_prepare_inputs.py` | 检查输入长度、共享前缀和 token 范围 |
| `src/target1/save_inputs.py` | 保存两组 `requests.jsonl` 和共享组 `warmup.json` |
| `src/target1/measure.py` | 逐请求记录 TTFT、TPOT、端到端耗时及服务返回的 token 信息 |
| `src/target1/replay.py` | 预检、清缓存、预热，并以最大并发 8 回放指定组 |
| `src/target1/summarize.py` | 核验逐请求结果并生成 `summary.csv` |

`results/target1/shared_prefix/` 与 `results/target1/dispersed_prefix/` 各有输入清单和 32 条 `request_results.jsonl`；共享组另有 `warmup.json`。`results/target1/summary.csv` 对应 `report.pdf` 第 1 页的任务一对照表。缓存命中率按 `sum(cached_tokens) / sum(prompt_tokens)` 计算；实际 Prefill token 为 `sum(prompt_tokens - cached_tokens)`；吞吐量是 512 个输出 token 除以该组最早开始到最晚结束的时间跨度。报告第 2–3 页为 v0.5.14 请求流程图、源码位置和分析。
