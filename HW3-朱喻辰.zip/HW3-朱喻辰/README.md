# 第三次挑战：比较并改进 Ray Serve 路由

本目录保存第三次挑战的代码、固定负载和实验结果。技术分析见 `report.pdf`；AI 使用情况见 `AI 使用说明情况（第三次挑战）.pdf`。第二次挑战已经完成的 Target 1 代码和结果一并收录，供复现与核对。

## 目录

| 路径 | 内容 |
| --- | --- |
| `src/target1/` | 第二次挑战的 Target 1 代码 |
| `src/target3/serve_app.py` | Ray 集群、四个固定后端的 Serve 部署和请求转发 |
| `src/target3/routing.py` | D 策略：结合会话亲和与当前队列长度选择副本 |
| `src/target3/requirements.txt` | Target 3 使用的 Python 依赖 |
| `src/target3/workload/` | 课程固定负载、校验、运行和汇总脚本 |
| `results/target1/` | 第二次挑战 Target 1 的共享前缀、分散前缀结果 |
| `results/target3/` | A、B 两个候选、C、D 的完整请求记录、摘要、配置和日志 |

## 实验环境

- 同一台 AutoDL 主机，4 × NVIDIA A100 PCIe 40 GB；每张卡运行一个配置相同的 SGLang 后端。
- Python 3.12；SGLang 0.5.14；Ray Serve 2.56.0；模型 `Qwen/Qwen3-0.6B`。
- 一个 Ray head、四个逻辑 worker；每个 worker 放置一个 Serve replica，分别固定转发至本机端口 30000、30001、30002、30003。Ray Serve 的单个 HTTP 入口为 `127.0.0.1:8000`。
- 正式负载为 `src/target3/workload/mooncake_prefix_workload_v2_seed2026.jsonl`，SHA-256：`f154ba954e28ca9612257edf5deb0d5dfc6bf27fd0115a701e1f49e52df75b03`。64 条预热请求、2048 条计量请求、64 个前缀家族。各策略使用同一文件，未修改负载。

## 复现 Target 3

以下命令在具有四张 GPU 的 Linux 主机上执行。假设解压目录为 `/root/autodl-tmp/hw3`，模型位于 `/root/autodl-tmp/models/Qwen3-0.6B`，虚拟环境位于 `/root/autodl-tmp/sglang-env`。若路径不同，先替换命令中的对应路径。各长期运行服务分别保留一个终端。

### 1. 安装依赖、下载模型并校验负载

```bash
python3 -m venv /root/autodl-tmp/sglang-env
/root/autodl-tmp/sglang-env/bin/python -m pip install 'sglang==0.5.14' 'ray[serve]==2.56.0' -r /root/autodl-tmp/hw3/src/target3/requirements.txt
/root/autodl-tmp/sglang-env/bin/python -m pip check
HF_ENDPOINT=https://hf-mirror.com HF_HOME=/root/autodl-tmp/hf-cache HF_HUB_DISABLE_XET=1 \
  /root/autodl-tmp/sglang-env/bin/hf download Qwen/Qwen3-0.6B \
  --local-dir /root/autodl-tmp/models/Qwen3-0.6B
/root/autodl-tmp/sglang-env/bin/python /root/autodl-tmp/hw3/src/target3/workload/validate_workload.py /root/autodl-tmp/hw3/src/target3/workload/mooncake_prefix_workload_v2_seed2026.jsonl
```

校验结果应显示 64 个前缀家族、64 条预热、2048 条计量请求以及上面的 SHA-256。模型权重不包含在交付包内。

### 2. 启动四个 SGLang 后端

在独立终端运行：

```bash
export PATH=/root/autodl-tmp/sglang-env/bin:$PATH
for i in 0 1 2 3; do
  CUDA_VISIBLE_DEVICES=$i nohup python -m sglang.launch_server \
    --model-path /root/autodl-tmp/models/Qwen3-0.6B \
    --host 127.0.0.1 --port $((30000+i)) --tp 1 \
    > /root/autodl-tmp/sglang-gpu${i}.log 2>&1 &
done
for port in 30000 30001 30002 30003; do
  curl -fsS -o /dev/null -w "$port HTTP %{http_code}\n" "http://127.0.0.1:$port/model_info"
done
```

四个端口均返回 HTTP 200 后再启动 Ray Serve。

### 3. 逐个部署并运行策略

每次只运行一个策略。Serve 终端先执行下方命令，并保持运行：

```bash
cd /root/autodl-tmp/hw3/src/target3
export PATH=/root/autodl-tmp/sglang-env/bin:$PATH
export PYTHONPATH=/root/autodl-tmp/hw3/src/target3
python serve_app.py --policy A --max-ongoing 5
```

出现 `Ray Serve ready at http://127.0.0.1:8000/generate` 表示入口就绪。A、B8、B32、C、D 分别使用 `A 5`、`B 8`、`B 32`、`C 32`、`D 32`。切换策略前在 Serve 终端按 Ctrl+C，待进程退出后执行 `ray stop --force`，再按新参数启动；不要同时运行两个策略。

每轮开始前，在另一个终端清空四个后端缓存：

```bash
for port in 30000 30001 30002 30003; do
  curl -fsS -o /dev/null -w "$port HTTP %{http_code}\n" -X POST "http://127.0.0.1:$port/flush_cache"
done
```

四个端口均返回 HTTP 200 后运行固定负载。下例为 A；其他策略替换 `--run-name`、`--router-name`、`--max-ongoing-requests` 和输出目录。`--router-name` 只记录配置，真正的路由器由 `serve_app.py --policy` 指定；记录值必须与实际部署一致。A、B1、B2 使用 `p2c`，C 使用 `consistent_hash`，D 使用 `balanced_affinity`。

```bash
cd /root/autodl-tmp/hw3/src/target3/workload
/root/autodl-tmp/sglang-env/bin/python run_workload.py \
  --policy serve --run-name A_replay_run1 \
  --router-name p2c --max-ongoing-requests 5 \
  --base-url http://127.0.0.1:8000 \
  --workload mooncake_prefix_workload_v2_seed2026.jsonl \
  --max-in-flight 2048 \
  --output-dir /root/autodl-tmp/hw3-replay/A/run-1
```

此回放示例把新结果写到交付目录之外，避免覆盖已有的正式记录。正式结果目录的每轮子目录包含 `config.json`、`warmups.csv`、`requests.csv`、`summary.json`，运行日志保存在相邻的 `.log` 文件中。检查 `summary.json` 的成功数是否为 2048，并核对四个后端、四个 Ray 节点、四个 Serve 副本均收到请求。

## 结果索引和有效性

| 报告名称 | 结果目录 | Serve 配置 |
| --- | --- | --- |
| A | `results/target3/A_default/run-2/` | 默认路由，`max_ongoing_requests=5` |
| B1 | `results/target3/B_candidates/candidate-8/run-1/` | 默认路由，`max_ongoing_requests=8` |
| B2 | `results/target3/B_candidates/candidate-32/run-1/` | 默认路由，`max_ongoing_requests=32` |
| C | `results/target3/C_affinity/run-1/` | 一致性哈希会话亲和，`max_ongoing_requests=32` |
| D | `results/target3/D_improved/run-1/` | 当前队列长度感知的亲和路由，`max_ongoing_requests=32` |

上述五轮均为 2048/2048 条计量请求成功。A 的首次运行有一条后端连接复位，成功数为 2047/2048，因此未纳入正式比较；原始备份保留该轮供追溯。`results/target3/comparison.json` 汇总有效轮次。每组只有一轮有效计量，本报告仅陈述观察到的差异，不把它们当作多轮统计结论。

第二次挑战 Target 1 的共享前缀与分散前缀数据位于 `results/target1/shared_prefix/` 和 `results/target1/dispersed_prefix/`；其代码位于 `src/target1/`。
