"""D: keep prefix affinity unless its Serve replica is materially busier."""

import asyncio

from ray.serve.experimental.consistent_hash_router import ConsistentHashRouter


def choose_order(primary, loads, threshold):
    by_load = sorted(loads, key=loads.__getitem__)
    if loads[primary] <= loads[by_load[0]] + threshold:
        return [primary] + [replica for replica in by_load if replica != primary]
    return by_load


class BalancedAffinityRouter(ConsistentHashRouter):
    async def choose_replicas(self, candidate_replicas, pending_request=None):
        ranks = await super().choose_replicas(candidate_replicas, pending_request)
        if not ranks or pending_request is None:
            return ranks

        replicas = [rank[0] for rank in ranks]
        lengths = await asyncio.gather(
            *(asyncio.wait_for(replica.get_queue_len(deadline_s=0.2), 0.2)
              for replica in replicas),
            return_exceptions=True,
        )
        if any(isinstance(length, Exception) for length in lengths):
            return ranks

        by_id = {replica.replica_id: replica for replica in replicas}
        loads = dict(zip(by_id, lengths))
        return [[by_id[replica_id]] for replica_id in choose_order(
            replicas[0].replica_id, loads, threshold=2
        )]
