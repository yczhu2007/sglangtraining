"""Four fixed SGLang backends behind one Ray Serve /generate endpoint."""

import argparse
import time

import aiohttp
import ray
from ray import serve
from ray.cluster_utils import Cluster
from ray.serve.config import RequestRouterConfig
from starlette.requests import Request
from starlette.responses import Response, StreamingResponse


@serve.deployment
class BackendProxy:
    def __init__(self, node_to_backend):
        self.node_id = ray.get_runtime_context().get_node_id()
        self.backend_id, self.backend_url = node_to_backend[self.node_id]
        self.replica_id = str(serve.get_replica_context().replica_id)
        self.session = None

    async def __call__(self, request: Request):
        if request.method != "POST" or request.url.path != "/generate":
            return Response(status_code=404)

        forward_headers = {
            name: request.headers[name]
            for name in ("content-type", "x-session-id", "x-workload-request-id", "x-prefix-family")
            if name in request.headers
        }
        route_headers = {
            "X-Ray-Replica-ID": self.replica_id,
            "X-Ray-Node-ID": self.node_id,
            "X-SGLang-Backend": self.backend_id,
        }
        if self.session is None:
            self.session = aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=None))
        try:
            upstream = await self.session.post(
                f"{self.backend_url}/generate",
                data=await request.body(),
                headers=forward_headers,
            )
        except aiohttp.ClientError as exc:
            return Response(str(exc), status_code=502, headers=route_headers)

        if upstream.status != 200:
            body = await upstream.read()
            upstream.release()
            return Response(body, status_code=upstream.status, headers=route_headers)

        async def events():
            try:
                async for chunk in upstream.content.iter_any():
                    yield chunk
            finally:
                upstream.release()

        return StreamingResponse(events(), media_type="text/event-stream", headers=route_headers)


def start_cluster(backend_urls):
    if len(backend_urls) != 4:
        raise ValueError("exactly four backend URLs are required")
    cluster = Cluster()
    try:
        cluster.add_node(num_cpus=0, include_dashboard=False)
        node_to_backend = {}
        for index, url in enumerate(backend_urls):
            node = cluster.add_node(num_cpus=1)
            node_to_backend[str(node.node_id)] = (f"backend-{index}", url.rstrip("/"))
        ray.init(address=cluster.address)
        return cluster, node_to_backend
    except Exception:
        cluster.shutdown()
        raise


def deploy(policy, max_ongoing, node_to_backend):
    if policy == "A" and max_ongoing != 5:
        raise ValueError("A uses max_ongoing_requests=5")
    if policy == "B" and max_ongoing == 5:
        raise ValueError("B requires a non-default max_ongoing_requests value")
    if max_ongoing < 1:
        raise ValueError("max_ongoing_requests must be positive")

    options = {
        "num_replicas": 4,
        "max_replicas_per_node": 1,
        "max_ongoing_requests": max_ongoing,
        "ray_actor_options": {"num_cpus": 1},
    }
    if policy == "C":
        options["request_router_config"] = RequestRouterConfig(
            request_router_class=(
                "ray.serve.experimental.consistent_hash_router:ConsistentHashRouter"
            ),
            request_router_kwargs={"num_fallback_replicas": 0},
        )
    elif policy == "D":
        options["request_router_config"] = RequestRouterConfig(
            request_router_class="routing:BalancedAffinityRouter",
            request_router_kwargs={"num_fallback_replicas": 3},
        )
    serve.start(proxy_location="HeadOnly")
    serve.run(BackendProxy.options(**options).bind(node_to_backend), route_prefix="/")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--policy", choices=("A", "B", "C", "D"), required=True)
    parser.add_argument("--max-ongoing", type=int, default=5)
    parser.add_argument(
        "--backend-url", action="append", dest="backends",
        help="repeat four times in GPU 0..3 order",
    )
    args = parser.parse_args()
    urls = args.backends or [f"http://127.0.0.1:{30000 + i}" for i in range(4)]
    cluster, node_to_backend = start_cluster(urls)
    try:
        deploy(args.policy, args.max_ongoing, node_to_backend)
        print(f"{args.policy}: Ray Serve ready at http://127.0.0.1:8000/generate", flush=True)
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        pass
    finally:
        serve.shutdown()
        ray.shutdown()
        cluster.shutdown()


if __name__ == "__main__":
    main()
