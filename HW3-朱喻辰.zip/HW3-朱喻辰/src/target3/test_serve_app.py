import json
import threading
import unittest
from concurrent.futures import ThreadPoolExecutor
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.request import Request, urlopen

import ray
from ray import serve

from serve_app import deploy, start_cluster


class FakeBackend(BaseHTTPRequestHandler):
    def do_POST(self):
        body = json.loads(self.rfile.read(int(self.headers["Content-Length"])))
        event = {
            "output_ids": [7, 8],
            "meta_info": {
                "prompt_tokens": len(body["input_ids"]),
                "cached_tokens": 0,
            },
            "forwarded_session": self.headers["X-Session-Id"],
            "forwarded_request": self.headers["X-Workload-Request-ID"],
            "forwarded_family": self.headers["X-Prefix-Family"],
        }
        payload = ("data: " + json.dumps(event) + "\n\n").encode()
        self.send_response(200)
        self.send_header("Content-Type", "text/event-stream")
        self.send_header("Content-Length", str(len(payload)))
        self.end_headers()
        self.wfile.write(payload)

    def log_message(self, *_args):
        pass


def send(index):
    body = json.dumps({"input_ids": [1, 2, 3], "stream": True}).encode()
    request = Request(
        "http://127.0.0.1:8000/generate",
        data=body,
        headers={
            "Content-Type": "application/json",
            "X-Session-Id": str(index),
            "X-Workload-Request-ID": str(index),
            "X-Prefix-Family": str(index),
        },
    )
    with urlopen(request, timeout=30) as response:
        event = json.loads(response.read().decode().removeprefix("data: ").strip())
        return response.headers, event


class ServeAppTests(unittest.TestCase):
    def test_four_replicas_forward_sse_and_routing_headers(self):
        backends = [ThreadingHTTPServer(("127.0.0.1", 0), FakeBackend) for _ in range(4)]
        for backend in backends:
            threading.Thread(target=backend.serve_forever, daemon=True).start()
        urls = [f"http://127.0.0.1:{backend.server_port}" for backend in backends]
        cluster = None
        try:
            cluster, mapping = start_cluster(urls)
            deploy("A", 5, mapping)
            with ThreadPoolExecutor(max_workers=24) as pool:
                responses = list(pool.map(send, range(24)))
            self.assertEqual(sum(node["Alive"] for node in ray.nodes()), 5)
            proxies = [
                actor for actor in ray.state.actors().values()
                if actor["State"] == "ALIVE" and actor["ActorClassName"] == "ProxyActor"
            ]
            self.assertEqual(len(proxies), 1)
            self.assertEqual(len({headers["X-SGLang-Backend"] for headers, _ in responses}), 4)
            self.assertEqual(len({headers["X-Ray-Node-ID"] for headers, _ in responses}), 4)
            self.assertEqual(len({headers["X-Ray-Replica-ID"] for headers, _ in responses}), 4)
            for index, (_, event) in enumerate(responses):
                self.assertEqual(event["forwarded_session"], str(index))
                self.assertEqual(event["forwarded_request"], str(index))
                self.assertEqual(event["forwarded_family"], str(index))
                self.assertEqual(event["output_ids"], [7, 8])

            serve.shutdown()
            deploy("B", 8, mapping)
            self.assertEqual(send(42)[1]["output_ids"], [7, 8])

            serve.shutdown()
            deploy("C", 8, mapping)
            affinity = [send(42)[0]["X-SGLang-Backend"] for _ in range(8)]
            self.assertEqual(len(set(affinity)), 1)

            serve.shutdown()
            deploy("D", 8, mapping)
            self.assertEqual(send(42)[1]["output_ids"], [7, 8])
        finally:
            if cluster:
                serve.shutdown()
                ray.shutdown()
                cluster.shutdown()
            for backend in backends:
                backend.shutdown()
                backend.server_close()


if __name__ == "__main__":
    unittest.main()
