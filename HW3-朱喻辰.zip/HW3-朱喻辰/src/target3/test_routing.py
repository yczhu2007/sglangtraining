import unittest

from routing import choose_order


class ChooseOrderTests(unittest.TestCase):
    def test_keeps_affinity_when_loads_are_close(self):
        self.assertEqual(choose_order("a", {"a": 3, "b": 2, "c": 1}, 2)[0], "a")

    def test_falls_back_when_affinity_is_busy(self):
        self.assertEqual(choose_order("a", {"a": 5, "b": 1, "c": 2}, 2)[0], "b")


if __name__ == "__main__":
    unittest.main()
