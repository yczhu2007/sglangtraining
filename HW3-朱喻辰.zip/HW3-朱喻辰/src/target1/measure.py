import json
import time
from pathlib import Path

import requests

URL = "http://127.0.0.1:30000/generate"
base = Path(__file__).resolve().parents[2] / "results" / "target1"
input_file = base / "shared_prefix" / "requests.jsonl"


def measure_one(item):
    body = {
        "input_ids": item["input_ids"],
        "stream": True,
        "sampling_params": {
            "temperature": 0,
            "max_new_tokens": 16,
            "ignore_eos": True,
            "sampling_seed": 2026,
        },
    }

    started = time.perf_counter()
    first_token = None
    last_token = None
    token_count = 0
    final_meta = {}

    with requests.post(URL, json=body, stream=True, timeout=180) as response:
        status = response.status_code
        response.raise_for_status()
        for raw_line in response.iter_lines(chunk_size=1):
            line = raw_line.decode("utf-8").strip()
            if not line.startswith("data:"):
                continue
            data = line[5:].strip()
            if data == "[DONE]":
                continue

            event = json.loads(data)
            if "error" in event:
                raise RuntimeError(event["error"])

            meta = event.get("meta_info") or {}
            count = int(meta.get("completion_tokens", 0))
            if count > token_count:
                now = time.perf_counter()
                if first_token is None:
                    first_token = now
                last_token = now
                token_count = count
            if meta:
                final_meta = meta

    finished = time.perf_counter()
    assert first_token is not None and token_count == 16
    assert final_meta["prompt_tokens"] == 2112

    return {
        "id": item["id"],
	"started_s": started,
	"finished_s": finished,
        "status": status,
        "prompt_tokens": final_meta["prompt_tokens"],
        "completion_tokens": final_meta["completion_tokens"],
        "cached_tokens": final_meta["cached_tokens"],
        "ttft_s": round(first_token - started, 6),
        "tpot_s": round((last_token - first_token) / (token_count - 1), 6),
        "latency_s": round(finished - started, 6),
    }


if __name__ == "__main__":
    with input_file.open(encoding="utf-8") as source:
        first_item = json.loads(next(source))
    print(json.dumps(measure_one(first_item), ensure_ascii=False, indent=2))
