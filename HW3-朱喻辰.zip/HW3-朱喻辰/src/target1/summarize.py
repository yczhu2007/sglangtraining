import csv
import json
from pathlib import Path

RESULTS = Path(__file__).resolve().parents[2] / "results" / "target1"


def percentile(values, fraction):
    values = sorted(values)
    position = (len(values) - 1) * fraction
    lower = int(position)
    upper = min(lower + 1, len(values) - 1)
    return values[lower] + (values[upper] - values[lower]) * (position - lower)


def analyze(name):
    path = RESULTS / name / "request_results.jsonl"
    with path.open(encoding="utf-8") as source:
        rows = [json.loads(line) for line in source]

    assert len(rows) == 32
    assert [r["id"] for r in rows] == list(range(1, 33))
    assert all(r["status"] == 200 for r in rows)
    assert all(r["prompt_tokens"] == 2112 for r in rows)
    assert all(r["completion_tokens"] == 16 for r in rows)
    assert all(r["started_s"] < r["finished_s"] for r in rows)
    assert all(0 <= r["cached_tokens"] <= 2112 for r in rows)

    prompt = sum(r["prompt_tokens"] for r in rows)
    cached = sum(r["cached_tokens"] for r in rows)
    output = sum(r["completion_tokens"] for r in rows)
    elapsed = max(r["finished_s"] for r in rows) - min(
        r["started_s"] for r in rows
    )
    assert elapsed > 0

    result = {
        "group": name,
        "success_rate_pct": 100.0,
        "input_tokens_each": 2112,
        "output_tokens_each": 16,
        "output_tokens_per_s": round(output / elapsed, 3),
        "cache_hit_rate_pct": round(100 * cached / prompt, 2),
        "actual_prefill_tokens": prompt - cached,
    }

    for key in ("ttft_s", "tpot_s", "latency_s"):
        values_ms = [r[key] * 1000 for r in rows]
        label = key.removesuffix("_s")
        result[f"{label}_p50_ms"] = round(percentile(values_ms, 0.50), 3)
        result[f"{label}_p95_ms"] = round(percentile(values_ms, 0.95), 3)

    return result


shared = analyze("shared_prefix")
dispersed = analyze("dispersed_prefix")

assert shared["cache_hit_rate_pct"] > dispersed["cache_hit_rate_pct"]
assert shared["actual_prefill_tokens"] < dispersed["actual_prefill_tokens"]

summary_path = RESULTS / "summary.csv"
with summary_path.open("w", newline="", encoding="utf-8-sig") as output:
    writer = csv.DictWriter(output, fieldnames=list(shared))
    writer.writeheader()
    writer.writerows([shared, dispersed])

for row in (shared, dispersed):
    print(
        row["group"],
        "成功率:", row["success_rate_pct"], "%",
        "命中率:", row["cache_hit_rate_pct"], "%",
        "实际 Prefill:", row["actual_prefill_tokens"],
        "输出吞吐:", row["output_tokens_per_s"], "token/s",
    )

print("两组对照检查通过")
print("完整表格：", summary_path)
