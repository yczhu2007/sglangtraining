from run import DISPERSED, PREFIX, SHARED, WARMUP, tokenizer


def check_inputs():
    assert len(SHARED) == len(DISPERSED) == 32
    assert len(WARMUP) == 2112
    assert all(len(ids) == 2112 for ids in SHARED + DISPERSED)
    assert all(ids[:2048] == PREFIX for ids in SHARED)
    assert len({token for ids in DISPERSED for token in ids}) == 32 * 2112
    assert max(token for ids in SHARED + DISPERSED + [WARMUP] for token in ids) < len(tokenizer)
    print("输入检查通过：两组各 32 条，每条 2112 token，共享前缀 2048 token")


if __name__ == "__main__":
    check_inputs()
