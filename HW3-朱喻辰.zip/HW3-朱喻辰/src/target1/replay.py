import json
import sys
from pathlib import Path

import ray
import requests

from measure import URL, measure_one

SOURCE_DIR = Path(__file__).resolve().parent
RESULTS = SOURCE_DIR.parents[1] / "results" / "target1"


def load_group(name):
    path = RESULTS / name / "requests.jsonl"
    with path.open(encoding="utf-8") as source:
        items = [json.loads(line) for line in source]

    assert len(items) == 32
    assert [item["id"] for item in items] == list(range(1, 33))
    assert all(len(item["input_ids"]) == 2112 for item in items)
    print(f"{name}: 已检查 32 条，每条 2112 token")
    return items


def flush_cache():
    response = requests.post(
        "http://127.0.0.1:30000/flush_cache",
        timeout=30,
    )
    assert response.status_code == 200, response.text
    assert "Cache flushed." in response.text
    print("缓存清除成功")


@ray.remote(num_cpus=1)
def send_remote(item):
    from measure import measure_one

    return measure_one(item)


def run_group(name, items):
    output_path = RESULTS / name / "request_results.jsonl"
    if output_path.exists():
        raise FileExistsError(
            f"{output_path} 已存在；先保留或改名，再决定是否重新实验"
        )

    flush_cache()

    if name == "shared_prefix":
        warmup_path = RESULTS / name / "warmup.json"
        warmup = json.loads(warmup_path.read_text(encoding="utf-8"))
        result = measure_one({"id": 0, **warmup})
        print("共享前缀预热完成；不计入结果，HTTP 状态：", result["status"])

    completed = 0
    with output_path.open("x", encoding="utf-8") as output:
        for start in range(0, 32, 8):
            batch = items[start:start + 8]
            futures = [send_remote.remote(item) for item in batch]
            results = ray.get(futures)

            for result in results:
                output.write(json.dumps(result, ensure_ascii=False) + "\n")
                completed += 1

            output.flush()
            print(f"{name}: 已完成 {completed}/32")

    assert completed == 32
    print("结果已保存：", output_path)


if __name__ == "__main__":
    shared = load_group("shared_prefix")
    dispersed = load_group("dispersed_prefix")

    if len(sys.argv) == 2 and sys.argv[1] == "--check":
        print("预检通过；没有向服务发送请求")
        sys.exit(0)

    if len(sys.argv) != 2 or sys.argv[1] not in (
        "shared_prefix",
        "dispersed_prefix",
    ):
        raise SystemExit("用法：replay.py --check|shared_prefix|dispersed_prefix")

    selected = sys.argv[1]

    ray.init(
        num_cpus=8,
        include_dashboard=False,
        logging_level="ERROR",
        runtime_env={"working_dir": str(SOURCE_DIR)},
    )
    try:
        # 实验前用短请求预热服务；随后的 flush 会清掉它的缓存。
        response = requests.post(
            URL,
            json={
                "input_ids": [900, 901, 902, 903],
                "sampling_params": {
                    "temperature": 0,
                    "max_new_tokens": 16,
                    "ignore_eos": True,
                    "sampling_seed": 2026,
                },
            },
            timeout=180,
        )
        response.raise_for_status()
        print("短请求服务预热完成")

        items = shared if selected == "shared_prefix" else dispersed
        run_group(selected, items)
    finally:
        ray.shutdown()
