import json
from pathlib import Path

from run import SHARED, DISPERSED, WARMUP

base = Path(__file__).resolve().parents[2] / "results" / "target1"

for name, requests in (
    ("shared_prefix", SHARED),
    ("dispersed_prefix", DISPERSED),
):
    folder = base / name
    folder.mkdir(parents=True, exist_ok=True)
    path = folder / "requests.jsonl"
    with path.open("w", encoding="utf-8") as output:
        for number, input_ids in enumerate(requests, start=1):
            output.write(
                json.dumps({"id": number, "input_ids": input_ids}) + "\n"
            )
    print(f"{path}: {len(requests)} 条")

warmup_path = base / "shared_prefix" / "warmup.json"
warmup_path.write_text(
    json.dumps({"input_ids": WARMUP}), encoding="utf-8"
)
print(f"{warmup_path}: 1 条")
