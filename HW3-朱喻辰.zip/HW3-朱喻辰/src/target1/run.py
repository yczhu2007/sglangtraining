import json
from urllib.request import Request, urlopen
from transformers import AutoTokenizer

PREFIX = list(range(1000, 3048))  # 2048 个 token
WARMUP = PREFIX + list(range(8000, 8064))

SHARED = [
    PREFIX + list(range(4000 + i * 64, 4000 + (i + 1) * 64))
    for i in range(32)
]
DISPERSED = [
    list(range(10000 + i * 2112, 10000 + (i + 1) * 2112))
    for i in range(32)
]

tokenizer = AutoTokenizer.from_pretrained(
    "Qwen/Qwen3-0.6B", local_files_only=True
)

assert len(SHARED) == len(DISPERSED) == 32
assert len(WARMUP) == 2112
assert all(len(x) == 2112 for x in SHARED + DISPERSED)
assert all(x[:2048] == PREFIX for x in SHARED)
assert len({token for x in DISPERSED for token in x}) == 32 * 2112
assert max(token for x in SHARED + DISPERSED + [WARMUP] for token in x) < len(tokenizer)

print("两组各 32 条；每条输入 2112 token；预热请求 2112 token")
print("共享前缀长度：", len(PREFIX))
print("模型 tokenizer 大小：", len(tokenizer))
if __name__ == "__main__":
    body = {
        "input_ids": SHARED[0],
        "stream": True,
        "sampling_params": {
            "temperature": 0,
            "max_new_tokens": 16,
            "ignore_eos": True,
            "sampling_seed": 2026,
        },
    }
    request = Request(
        "http://127.0.0.1:30000/generate",
        data=json.dumps(body).encode("utf-8"),
        headers={"Content-Type": "application/json"},
    )

    last_event = None
    event_count = 0
    with urlopen(request, timeout=180) as response:
        print("HTTP 状态：", response.status)
        for raw_line in response:
            line = raw_line.decode("utf-8").strip()
            if not line.startswith("data: "):
                continue
            data = line[6:]
            if data == "[DONE]":
                continue
            last_event = json.loads(data)
            if "error" in last_event:
                raise RuntimeError(last_event["error"])
            event_count += 1

    assert last_event is not None
    meta = last_event["meta_info"]
    print("流式事件数：", event_count)
    print("prompt_tokens：", meta["prompt_tokens"])
    print("completion_tokens：", meta["completion_tokens"])
    print("cached_tokens：", meta["cached_tokens"])
    assert meta["prompt_tokens"] == 2112
    assert meta["completion_tokens"] == 16
